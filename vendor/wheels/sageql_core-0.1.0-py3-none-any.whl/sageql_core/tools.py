from dataclasses import dataclass
from typing import Optional, cast

from pydantic import BaseModel, Field, StrictStr, ValidationError

from .control import ActionRejected, RunContext, RunControl
from .models import (
    AnalysisPlan,
    ApprovedObservation,
    ContractModel,
    Decision,
    Query,
    Submission,
    ToolDefinition,
    ToolName,
)
from .protocols import (
    AnalysisExecutor,
    DatasetProvider,
    KnowledgeProvider,
    ObservationPolicy,
)


class DiscoverArguments(ContractModel):
    goal: StrictStr = Field(min_length=1, max_length=1000)


class KnowledgeArguments(ContractModel):
    query: StrictStr = Field(min_length=1, max_length=1000)


class DescribeArguments(ContractModel):
    dataset_id: StrictStr = Field(min_length=1, max_length=80)


class InspectArguments(ContractModel):
    dataset_ref: StrictStr = Field(min_length=1, max_length=120)


class EnsureArguments(ContractModel):
    query: Query


class AnalyzeArguments(ContractModel):
    plan: AnalysisPlan


class FinishArguments(ContractModel):
    submission: Submission


_SCHEMAS: dict[ToolName, tuple[type[BaseModel], str]] = {
    "discover_datasets": (
        DiscoverArguments,
        "Discover host-authorized datasets and safe coverage descriptions.",
    ),
    "lookup_knowledge": (
        KnowledgeArguments,
        "Look up reviewed current knowledge; factory instances require data results.",
    ),
    "describe_dataset": (
        DescribeArguments,
        "Describe normalized fields, grain, coverage and approved metrics.",
    ),
    "ensure_dataset": (
        EnsureArguments,
        "Resolve authorized interaction data, then sufficient cache, then bounded upstream.",
    ),
    "inspect_dataset": (
        InspectArguments,
        "Inspect a current authorized dataset reference without exposing raw rows.",
    ),
    "analyze_dataset": (
        AnalyzeArguments,
        "Run a structured, host-reviewed analysis on authorized references.",
    ),
    "finish_or_clarify": (
        FinishArguments,
        "Submit host-validated result or knowledge references, clarify, or report unavailable.",
    ),
}


@dataclass(frozen=True)
class ToolOutcome:
    observation: Optional[ApprovedObservation] = None
    submission: Optional[Submission] = None


class DataTools:
    def __init__(
        self,
        datasets: DatasetProvider,
        knowledge: KnowledgeProvider,
        executor: AnalysisExecutor,
        policy: ObservationPolicy,
    ) -> None:
        self.datasets = datasets
        self.knowledge = knowledge
        self.executor = executor
        self.policy = policy

    @property
    def definitions(self) -> tuple[ToolDefinition, ...]:
        return tuple(
            ToolDefinition(
                name=name,
                description=description,
                parameters=cast(dict[str, object], schema.model_json_schema()),
            )
            for name, (schema, description) in _SCHEMAS.items()
        )

    def validate(self, decision: Decision) -> BaseModel:
        try:
            schema = _SCHEMAS[decision.tool][0]
            return schema.model_validate(decision.arguments)
        except (KeyError, ValidationError):
            raise ActionRejected("invalid_action") from None

    async def execute(
        self,
        decision: Decision,
        context: RunContext,
        control: RunControl,
    ) -> ToolOutcome:
        arguments = self.validate(decision)
        control.check()
        await self.policy.authorize(context, decision.tool, arguments)
        control.check()
        result: object
        if isinstance(arguments, DiscoverArguments):
            result = await self.datasets.discover(context, arguments.goal, control)
        elif isinstance(arguments, KnowledgeArguments):
            result = await self.knowledge.lookup(context, arguments.query, control)
        elif isinstance(arguments, DescribeArguments):
            result = await self.datasets.describe(
                context, arguments.dataset_id, control
            )
        elif isinstance(arguments, EnsureArguments):
            result = await self.datasets.ensure(context, arguments.query, control)
        elif isinstance(arguments, InspectArguments):
            result = await self.datasets.inspect(
                context, arguments.dataset_ref, control
            )
        elif isinstance(arguments, AnalyzeArguments):
            control.consume("analyses")
            result = await self.executor.analyze(context, arguments.plan, control)
        elif isinstance(arguments, FinishArguments):
            if not await self.executor.validate_submission(
                context, arguments.submission, control
            ):
                raise ActionRejected("invalid_submission")
            control.check()
            return ToolOutcome(submission=arguments.submission)
        else:
            raise ActionRejected("invalid_action")
        control.check()
        approved_value = cast(
            object, await self.policy.approve(context, decision.tool, result)
        )
        if not isinstance(approved_value, ApprovedObservation):
            raise ActionRejected("observation_failed")
        # Revalidation prevents mutated/model-constructed instances bypassing the boundary.
        approved = ApprovedObservation.model_validate(approved_value.model_dump())
        control.check()
        control.consume("result_bytes", len(approved.model_dump_json().encode("utf-8")))
        return ToolOutcome(observation=approved)
