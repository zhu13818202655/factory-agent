import asyncio
import logging
from typing import Literal, Optional, cast

from pydantic import ValidationError

from .control import (
    ActionRejected,
    BoundedController,
    RunContext,
    RunControl,
    RunStopped,
)
from .models import (
    ApprovedObservation,
    Decision,
    ModelRequest,
    NormalizedEvent,
    RunResult,
    SafeCode,
)
from .protocols import AgentModel, EventSink
from .tools import AnalyzeArguments, DataTools, FinishArguments, InspectArguments

logger = logging.getLogger(__name__)
LiteralStatus = Literal[
    "completed", "clarify", "unavailable", "denied", "stopped", "failed"
]
LiteralEventKind = Literal["phase", "usage", "complete", "failure", "warning"]


class Agent:
    def __init__(
        self,
        model: AgentModel,
        tools: DataTools,
        event_sink: Optional[EventSink] = None,
    ) -> None:
        self.model = model
        self.tools = tools
        self.event_sink = event_sink

    async def _emit(self, event: NormalizedEvent, control: RunControl) -> None:
        if self.event_sink is None:
            return
        try:
            # Non-authoritative observers cannot change authorization or business outcomes.
            await asyncio.wait_for(
                self.event_sink.emit(event),
                timeout=min(1.0, control.limits.call_timeout),
            )
        except Exception:
            # Exception text is intentionally never serialized or logged.
            logger.warning("event_sink_failed")

    def _check_references(
        self,
        decision: Decision,
        observations: list[ApprovedObservation],
    ) -> None:
        arguments = self.tools.validate(decision)
        dataset_refs = {ref for obs in observations for ref in obs.dataset_refs}
        result_refs = {ref for obs in observations for ref in obs.result_refs}
        knowledge_refs = {ref for obs in observations for ref in obs.knowledge_refs}
        knowledge_refs.update(
            piece.reference for obs in observations for piece in obs.knowledge
        )
        if isinstance(arguments, InspectArguments):
            if arguments.dataset_ref not in dataset_refs:
                raise ActionRejected("unknown_reference")
        elif isinstance(arguments, AnalyzeArguments):
            if not set(arguments.plan.dataset_refs).issubset(dataset_refs):
                raise ActionRejected("unknown_reference")
        elif isinstance(arguments, FinishArguments):
            submission = arguments.submission
            if not set(submission.result_refs).issubset(result_refs):
                raise ActionRejected("unknown_reference")
            if not set(submission.knowledge_refs).issubset(knowledge_refs):
                raise ActionRejected("unknown_reference")

    async def run(
        self, question: str, context: RunContext, control: RunControl
    ) -> RunResult:
        observations: list[ApprovedObservation] = []
        repair_code: Optional[SafeCode] = None
        repairs = 0

        async def decide() -> Decision:
            request = ModelRequest(
                question=question,
                observations=tuple(observations),
                tools=self.tools.definitions,
                repair_code=repair_code,
            )
            try:
                decision = await self.model.decide(request)
                return Decision.model_validate(decision)
            except ValidationError:
                raise ActionRejected("invalid_action") from None

        async def next_decision() -> Decision:
            nonlocal repair_code, repairs
            try:
                return await decide()
            except ActionRejected as rejected:
                if rejected.code != "invalid_action" or repairs >= 1:
                    raise
                control.consume("semantic_repairs")
                repairs += 1
                repair_code = rejected.code
                control.consume("model_rounds")
                await self._emit(NormalizedEvent(kind="phase", phase="repair"), control)
                return await decide()

        try:
            control.check()
            controller: BoundedController[Decision] = BoundedController(control)
            await self._emit(NormalizedEvent(kind="phase", phase="plan"), control)
            async for decision in controller.iterate(next_decision):
                try:
                    self._check_references(decision, observations)
                    control.consume("tool_steps")
                    await self._emit(
                        NormalizedEvent(kind="phase", phase="tool"), control
                    )
                    outcome = await control.with_call(
                        lambda action=decision: self.tools.execute(
                            action, context, control
                        )
                    )
                    repair_code = None
                    if outcome.submission is not None:
                        control.finish()
                        kind = outcome.submission.kind
                        status = (
                            "completed" if kind in ("result", "knowledge") else kind
                        )
                        await self._emit(
                            self._usage_event("complete", control), control
                        )
                        return RunResult(
                            status=cast("LiteralStatus", status),
                            submission=outcome.submission,
                            observations=tuple(observations),
                        )
                    if outcome.observation is not None:
                        control.record_progress(
                            decision.model_dump_json(),
                            outcome.observation.model_dump_json(),
                        )
                        observations.append(outcome.observation)
                    await self._emit(self._usage_event("usage", control), control)
                except ActionRejected as rejected:
                    if (
                        rejected.code not in ("invalid_action", "invalid_submission")
                        or repairs >= 1
                    ):
                        raise
                    control.consume("semantic_repairs")
                    repairs += 1
                    repair_code = rejected.code
                    observations.append(
                        ApprovedObservation(
                            state="invalid_action", reason_code=rejected.code
                        )
                    )
                    await self._emit(
                        NormalizedEvent(kind="phase", phase="repair"), control
                    )
            raise RunStopped("execution_failed")
        except RunStopped as stopped:
            control.stop(stopped.code)
            await self._emit(
                NormalizedEvent(kind="failure", phase="finish", outcome=stopped.code),
                control,
            )
            return RunResult(
                status="stopped",
                reason_code=stopped.code,
                observations=tuple(observations),
            )
        except ActionRejected as rejected:
            control.stop(rejected.code)
            await self._emit(
                NormalizedEvent(kind="failure", phase="finish", outcome=rejected.code),
                control,
            )
            status = "denied" if rejected.code == "denied" else "unavailable"
            return RunResult(
                status=status,
                reason_code=rejected.code,
                observations=tuple(observations),
            )
        except Exception:
            control.stop("execution_failed")
            await self._emit(
                NormalizedEvent(
                    kind="failure", phase="finish", outcome="execution_failed"
                ),
                control,
            )
            return RunResult(
                status="failed",
                reason_code="execution_failed",
                observations=tuple(observations),
            )

    @staticmethod
    def _usage_event(kind: str, control: RunControl) -> NormalizedEvent:
        return NormalizedEvent(
            kind=cast("LiteralEventKind", kind),
            phase="finish" if kind == "complete" else "tool",
            model_rounds=control.used("model_rounds"),
            tool_steps=control.used("tool_steps"),
            analyses=control.used("analyses"),
            model_tokens=control.used("model_tokens"),
        )
