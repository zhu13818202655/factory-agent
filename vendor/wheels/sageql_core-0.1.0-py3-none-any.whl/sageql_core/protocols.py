from typing import Protocol

from pydantic import BaseModel

from .control import RunContext, RunControl
from .models import (
    AnalysisPlan,
    ApprovedObservation,
    Decision,
    ModelRequest,
    NormalizedEvent,
    Query,
    Submission,
)


class AgentModel(Protocol):
    async def decide(self, request: ModelRequest) -> Decision: ...


class DatasetProvider(Protocol):
    async def discover(
        self, context: RunContext, goal: str, control: RunControl
    ) -> object: ...
    async def describe(
        self, context: RunContext, dataset_id: str, control: RunControl
    ) -> object: ...
    async def ensure(
        self, context: RunContext, query: Query, control: RunControl
    ) -> object: ...
    async def inspect(
        self, context: RunContext, dataset_ref: str, control: RunControl
    ) -> object: ...


class KnowledgeProvider(Protocol):
    async def lookup(
        self, context: RunContext, query: str, control: RunControl
    ) -> object: ...


class AnalysisExecutor(Protocol):
    async def analyze(
        self, context: RunContext, plan: AnalysisPlan, control: RunControl
    ) -> object: ...
    async def validate_submission(
        self, context: RunContext, submission: Submission, control: RunControl
    ) -> bool: ...


class ObservationPolicy(Protocol):
    async def authorize(
        self, context: RunContext, tool: str, arguments: BaseModel
    ) -> None: ...
    async def approve(
        self, context: RunContext, tool: str, result: object
    ) -> ApprovedObservation: ...


class EventSink(Protocol):
    async def emit(self, event: NormalizedEvent) -> None: ...
