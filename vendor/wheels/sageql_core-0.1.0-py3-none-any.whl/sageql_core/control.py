import asyncio
import hashlib
import math
import time
from collections.abc import AsyncIterator, Awaitable
from dataclasses import dataclass, field
from typing import (
    Callable,
    Generic,
    Literal,
    Optional,
    TypeVar,
)

from .models import SafeCode

Resource = Literal[
    "model_rounds",
    "tool_steps",
    "mes_requests",
    "mes_pages",
    "processed_rows",
    "analyses",
    "model_tokens",
    "result_bytes",
    "semantic_repairs",
]
T = TypeVar("T")


class RunStopped(Exception):
    def __init__(self, code: SafeCode):
        self.code: SafeCode = code
        super().__init__(code)


class ActionRejected(Exception):
    """A safe classification for host rejection, never a customer exception message."""

    def __init__(self, code: SafeCode = "denied"):
        self.code: SafeCode = code
        super().__init__(code)


@dataclass(frozen=True)
class RunLimits:
    max_model_rounds: int = 12
    max_semantic_repairs: int = 1
    max_tool_steps: int = 16
    max_mes_requests: int = 20
    max_mes_pages: int = 20
    max_processed_rows: int = 50000
    max_analyses: int = 6
    max_model_tokens: int = 30000
    max_result_bytes: int = 1048576
    max_concurrent_calls: int = 1
    no_progress_limit: int = 2
    call_timeout: float = 30.0

    def __post_init__(self) -> None:
        for name, value in self.__dict__.items():
            if name == "max_semantic_repairs":
                if type(value) is not int or value not in (0, 1):
                    raise ValueError("semantic_repair_limit_must_be_zero_or_one")
                continue
            valid_type = (
                type(value) in (int, float)
                if name == "call_timeout"
                else type(value) is int
            )
            if not valid_type or value <= 0 or not math.isfinite(value):
                raise ValueError("limits_must_be_positive")


@dataclass(frozen=True)
class RunContext:
    """Opaque host state deliberately excluded from model requests and observations."""

    host: object = field(repr=False)


class RunControl:
    def __init__(
        self,
        deadline: float,
        limits: Optional[RunLimits] = None,
        cancelled: Optional[Callable[[], bool]] = None,
        clock: Callable[[], float] = time.monotonic,
    ) -> None:
        if not math.isfinite(deadline):
            raise ValueError("deadline_must_be_finite")
        self.deadline = deadline
        self.limits = limits or RunLimits()
        self._cancelled = cancelled or (lambda: False)
        self._clock = clock
        self._used: dict[Resource, int] = {}
        self._progress: dict[str, int] = {}
        self._seen_observations: set[str] = set()
        self._active = 0
        self._finished = False
        self._stopped: Optional[SafeCode] = None

    @property
    def finished(self) -> bool:
        return self._finished

    @property
    def usage(self) -> dict[Resource, int]:
        return self._used.copy()

    def used(self, resource: Resource) -> int:
        return self._used.get(resource, 0)

    def stop(self, code: SafeCode) -> None:
        self._stopped = code
        self._finished = True

    def finish(self) -> None:
        self._finished = True

    def check(self) -> None:
        if self._stopped is not None:
            raise RunStopped(self._stopped)
        if self._finished:
            raise RunStopped("execution_failed")
        if self._cancelled():
            self.stop("cancelled")
            raise RunStopped("cancelled")
        if self._clock() >= self.deadline:
            self.stop("deadline_exceeded")
            raise RunStopped("deadline_exceeded")

    def consume(self, resource: Resource, amount: int = 1) -> None:
        self.check()
        if type(amount) is not int or amount < 0:
            raise ValueError("usage_must_be_nonnegative_integer")
        limit = getattr(self.limits, "max_" + resource, None)
        if not isinstance(limit, int):
            raise ValueError("unknown_resource")
        usage = self._used.get(resource, 0) + amount
        if usage > limit:
            self.stop("budget_exhausted")
            raise RunStopped("budget_exhausted")
        self._used[resource] = usage

    def restrict(self, limits: RunLimits) -> None:
        """Tighten shared limits without resetting prior work or the interaction deadline."""

        self.check()
        current = self.limits
        self.limits = RunLimits(
            max_model_rounds=min(current.max_model_rounds, limits.max_model_rounds),
            max_semantic_repairs=min(
                current.max_semantic_repairs, limits.max_semantic_repairs
            ),
            max_tool_steps=min(current.max_tool_steps, limits.max_tool_steps),
            max_mes_requests=min(current.max_mes_requests, limits.max_mes_requests),
            max_mes_pages=min(current.max_mes_pages, limits.max_mes_pages),
            max_processed_rows=min(
                current.max_processed_rows, limits.max_processed_rows
            ),
            max_analyses=min(current.max_analyses, limits.max_analyses),
            max_model_tokens=min(current.max_model_tokens, limits.max_model_tokens),
            max_result_bytes=min(current.max_result_bytes, limits.max_result_bytes),
            max_concurrent_calls=min(
                current.max_concurrent_calls, limits.max_concurrent_calls
            ),
            no_progress_limit=min(current.no_progress_limit, limits.no_progress_limit),
            call_timeout=min(current.call_timeout, limits.call_timeout),
        )
        if self._active > self.limits.max_concurrent_calls or any(
            amount > getattr(self.limits, "max_" + resource)
            for resource, amount in self._used.items()
        ):
            self.stop("budget_exhausted")
            raise RunStopped("budget_exhausted")

    def record_progress(self, action: str, observation: str) -> None:
        self.check()
        observation_digest = hashlib.sha256(observation.encode()).hexdigest()
        if observation_digest not in self._seen_observations:
            self._seen_observations.add(observation_digest)
            self._progress.clear()
        digest = hashlib.sha256((action + "\0" + observation).encode()).hexdigest()
        repeats = self._progress.get(digest, 0) + 1
        self._progress[digest] = repeats
        if repeats > self.limits.no_progress_limit:
            self.stop("no_progress")
            raise RunStopped("no_progress")

    async def with_call(
        self,
        callback: Callable[[], Awaitable[T]],
        timeout: Optional[float] = None,
    ) -> T:
        """Bound a call and cancel its awaited task on deadline, cancellation or timeout."""

        self.check()
        if self._active >= self.limits.max_concurrent_calls:
            raise RunStopped("budget_exhausted")
        remaining = self.deadline - self._clock()
        call_budget = min(
            remaining,
            self.limits.call_timeout,
            timeout if timeout is not None else self.limits.call_timeout,
        )
        if call_budget <= 0:
            self.stop("deadline_exceeded")
            raise RunStopped("deadline_exceeded")
        started_at = self._clock()
        call_deadline = started_at + call_budget
        self._active += 1
        task = asyncio.ensure_future(callback())
        try:
            while not task.done():
                self.check()
                effective_deadline = min(
                    call_deadline, started_at + self.limits.call_timeout
                )
                wait_time = min(0.1, effective_deadline - self._clock())
                if wait_time <= 0:
                    self.stop("deadline_exceeded")
                    raise RunStopped("deadline_exceeded")
                await asyncio.wait({task}, timeout=wait_time)
            self.check()
            return task.result()
        finally:
            self._active -= 1
            if not task.done():
                task.cancel()
                try:
                    await task
                except (asyncio.CancelledError, Exception):
                    pass


class BoundedController(Generic[T]):
    """The shared multi-round loop used by data agents and the SQL compatibility host."""

    def __init__(self, control: RunControl):
        self.control = control

    async def iterate(
        self,
        step: Callable[[], Awaitable[T]],
        terminal: Optional[Callable[[T], bool]] = None,
    ) -> AsyncIterator[T]:
        while not self.control.finished:
            self.control.check()
            self.control.consume("model_rounds")
            value = await self.control.with_call(step)
            yield value
            if self.control.finished or (terminal is not None and terminal(value)):
                return
            self.control.check()
