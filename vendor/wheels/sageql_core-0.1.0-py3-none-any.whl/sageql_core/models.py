from datetime import datetime
from typing import Literal, Optional, Union

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    StrictBool,
    StrictFloat,
    StrictInt,
    StrictStr,
    model_validator,
)

PROTOCOL_VERSION = "1"
ToolName = Literal[
    "discover_datasets",
    "lookup_knowledge",
    "describe_dataset",
    "ensure_dataset",
    "inspect_dataset",
    "analyze_dataset",
    "finish_or_clarify",
]
SafeCode = Literal[
    "invalid_action",
    "denied",
    "unavailable",
    "incomplete",
    "unknown_reference",
    "budget_exhausted",
    "cancelled",
    "deadline_exceeded",
    "no_progress",
    "execution_failed",
    "invalid_submission",
    "observation_failed",
]
ObservationState = Literal[
    "available",
    "interaction_reuse",
    "cache_hit",
    "live_fetch",
    "empty",
    "incomplete",
    "unavailable",
    "denied",
    "analyzed",
    "knowledge",
    "invalid_action",
]
Scalar = Union[StrictStr, StrictInt, StrictFloat, StrictBool]


class ContractModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True, hide_input_in_errors=True)


class Filter(ContractModel):
    field: StrictStr = Field(min_length=1, max_length=80)
    operator: Literal["eq", "in", "gte", "lt"] = "eq"
    values: tuple[Scalar, ...] = Field(min_length=1, max_length=100)

    @model_validator(mode="after")
    def validate_arity(self) -> "Filter":
        if self.operator != "in" and len(self.values) != 1:
            raise ValueError("filter_arity")
        return self


class SemanticParameter(ContractModel):
    name: StrictStr = Field(min_length=1, max_length=80)
    value: StrictStr = Field(max_length=120)


class Query(ContractModel):
    dataset_id: StrictStr = Field(min_length=1, max_length=80)
    columns: tuple[StrictStr, ...] = Field(default=(), max_length=64)
    filters: tuple[Filter, ...] = Field(default=(), max_length=16)
    window_start: Optional[datetime] = None
    window_end: Optional[datetime] = None
    semantics: tuple[SemanticParameter, ...] = Field(default=(), max_length=16)
    limit: StrictInt = Field(default=250000, ge=0, le=1000000)

    @model_validator(mode="after")
    def validate_window(self) -> "Query":
        if (self.window_start is None) != (self.window_end is None):
            raise ValueError("window_requires_both_bounds")
        for bound in (self.window_start, self.window_end):
            if bound is not None and bound.utcoffset() is None:
                raise ValueError("window_requires_timezone")
        if self.window_start is not None and self.window_end is not None:
            if self.window_start >= self.window_end:
                raise ValueError("window_order")
        return self


class Metric(ContractModel):
    metric_id: StrictStr = Field(min_length=1, max_length=80)
    operation: Literal["sum", "count", "count_distinct"] = "sum"


class Sort(ContractModel):
    field: StrictStr = Field(min_length=1, max_length=80)
    direction: Literal["asc", "desc"] = "asc"


class Join(ContractModel):
    left_ref: StrictStr = Field(min_length=1, max_length=120)
    right_ref: StrictStr = Field(min_length=1, max_length=120)
    left_keys: tuple[StrictStr, ...] = Field(min_length=1, max_length=4)
    right_keys: tuple[StrictStr, ...] = Field(min_length=1, max_length=4)
    cardinality: Literal["one_to_one", "many_to_one"]

    @model_validator(mode="after")
    def validate_keys(self) -> "Join":
        if len(self.left_keys) != len(self.right_keys):
            raise ValueError("join_key_arity")
        return self


class TimeBucket(ContractModel):
    field: StrictStr = Field(min_length=1, max_length=80)
    unit: Literal["day", "week", "month"]


class AnalysisPlan(ContractModel):
    dataset_refs: tuple[StrictStr, ...] = Field(min_length=1, max_length=4)
    group_by: tuple[StrictStr, ...] = Field(default=(), max_length=8)
    metrics: tuple[Metric, ...] = Field(default=(), max_length=16)
    filters: tuple[Filter, ...] = Field(default=(), max_length=16)
    order_by: tuple[Sort, ...] = Field(default=(), max_length=8)
    joins: tuple[Join, ...] = Field(default=(), max_length=3)
    time_bucket: Optional[TimeBucket] = None
    limit: StrictInt = Field(default=1000, ge=1, le=10000)

    @model_validator(mode="after")
    def validate_references(self) -> "AnalysisPlan":
        if len(set(self.dataset_refs)) != len(self.dataset_refs):
            raise ValueError("duplicate_dataset_reference")
        for join in self.joins:
            if (
                join.left_ref not in self.dataset_refs
                or join.right_ref not in self.dataset_refs
            ):
                raise ValueError("join_reference_missing")
            if join.left_ref == join.right_ref:
                raise ValueError("self_join_unavailable")
        return self


class FieldDescriptor(ContractModel):
    name: StrictStr = Field(min_length=1, max_length=80)
    data_type: Literal["string", "integer", "decimal", "date", "datetime", "boolean"]
    description: StrictStr = Field(default="", max_length=500)
    unit: Optional[StrictStr] = Field(default=None, max_length=80)
    validated: StrictBool = False
    sensitive: StrictBool = False


class DatasetDescriptor(ContractModel):
    dataset_id: StrictStr = Field(min_length=1, max_length=80)
    description: StrictStr = Field(default="", max_length=1000)
    fields: tuple[FieldDescriptor, ...] = Field(default=(), max_length=64)
    metrics: tuple[StrictStr, ...] = Field(default=(), max_length=32)
    grain: StrictStr = Field(default="unknown", max_length=120)
    contract_version: StrictStr = Field(default="1", max_length=80)
    data_version: Optional[StrictStr] = Field(default=None, max_length=80)
    rule_version: Optional[StrictStr] = Field(default=None, max_length=80)
    scope_state: Literal["authorized", "mes_filtered", "self", "unavailable"] = (
        "unavailable"
    )
    complete: Optional[StrictBool] = None
    available: StrictBool = False
    window_start: Optional[datetime] = None
    window_end: Optional[datetime] = None
    generated_at: Optional[datetime] = None
    timezone: Optional[StrictStr] = Field(default=None, max_length=80)


class KnowledgeSnippet(ContractModel):
    reference: StrictStr = Field(min_length=1, max_length=120)
    text: StrictStr = Field(min_length=1, max_length=4000)
    source: StrictStr = Field(min_length=1, max_length=240)
    version: StrictStr = Field(min_length=1, max_length=80)


class ApprovedObservation(ContractModel):
    """A host-approved projection; arbitrary rows, metadata and exceptions are absent."""

    state: ObservationState
    dataset_refs: tuple[StrictStr, ...] = Field(default=(), max_length=16)
    result_refs: tuple[StrictStr, ...] = Field(default=(), max_length=16)
    knowledge_refs: tuple[StrictStr, ...] = Field(default=(), max_length=16)
    descriptors: tuple[DatasetDescriptor, ...] = Field(default=(), max_length=16)
    knowledge: tuple[KnowledgeSnippet, ...] = Field(default=(), max_length=16)
    row_count: Optional[StrictInt] = Field(default=None, ge=0)
    missing_fields: tuple[StrictStr, ...] = Field(default=(), max_length=64)
    complete: Optional[StrictBool] = None
    source: Optional[Literal["interaction", "cache", "upstream", "knowledge"]] = None
    reason_code: Optional[SafeCode] = None


class Submission(ContractModel):
    kind: Literal["result", "knowledge", "clarify", "unavailable"]
    result_refs: tuple[StrictStr, ...] = Field(default=(), max_length=16)
    knowledge_refs: tuple[StrictStr, ...] = Field(default=(), max_length=16)
    clarification: Optional[StrictStr] = Field(default=None, max_length=1000)
    reason_code: Optional[SafeCode] = None

    @model_validator(mode="after")
    def validate_evidence(self) -> "Submission":
        if self.kind == "result":
            if (
                not self.result_refs
                or self.knowledge_refs
                or self.clarification is not None
            ):
                raise ValueError("result_evidence_required")
        elif self.kind == "knowledge":
            if (
                not self.knowledge_refs
                or self.result_refs
                or self.clarification is not None
            ):
                raise ValueError("knowledge_evidence_required")
        elif self.kind == "clarify":
            if not self.clarification or self.result_refs or self.knowledge_refs:
                raise ValueError("clarification_required")
        elif self.result_refs or self.knowledge_refs or self.clarification is not None:
            raise ValueError("unavailable_has_no_evidence")
        return self


class Decision(ContractModel):
    tool: ToolName
    arguments: dict[str, object] = Field(default_factory=dict)


class ToolDefinition(ContractModel):
    name: ToolName
    description: StrictStr
    parameters: dict[str, object]


class ModelRequest(ContractModel):
    question: StrictStr = Field(max_length=12000)
    observations: tuple[ApprovedObservation, ...] = ()
    tools: tuple[ToolDefinition, ...] = ()
    repair_code: Optional[SafeCode] = None
    protocol_version: Literal["1"] = PROTOCOL_VERSION


class NormalizedEvent(ContractModel):
    kind: Literal["phase", "usage", "complete", "failure", "warning"]
    phase: Literal["plan", "repair", "tool", "finish"]
    outcome: Optional[SafeCode] = None
    model_rounds: StrictInt = Field(default=0, ge=0)
    tool_steps: StrictInt = Field(default=0, ge=0)
    analyses: StrictInt = Field(default=0, ge=0)
    model_tokens: StrictInt = Field(default=0, ge=0)


class RunResult(ContractModel):
    status: Literal[
        "completed", "clarify", "unavailable", "denied", "stopped", "failed"
    ]
    submission: Optional[Submission] = None
    reason_code: Optional[SafeCode] = None
    observations: tuple[ApprovedObservation, ...] = ()
